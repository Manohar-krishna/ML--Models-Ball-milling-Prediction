import numpy as np
import pandas as pd
from xgboost import XGBRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_squared_error

# Dataset
data = {
    'ball_size': [10, 10, 10, 10, 10, 10, 5, 5, 5],
    'rpm': [600, 600, 600, 400, 400, 400, 400, 400, 400],
    'time': [24, 48, 72, 24, 48, 72, 24, 48, 72],
    'sphericity': [0.79464743, 0.81355519, 0.82061402, 0.76501041, 0.79116524, 0.72118172, 0.84585709, 0.87625333, 0.90514226]
}

# Convert to DataFrame
df = pd.DataFrame(data)

# Features and Target
X = df[['ball_size', 'rpm', 'time']]
y = df['sphericity']

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# XGBoost Regressor
model = XGBRegressor(objective='reg:squarederror', random_state=42)
model.fit(X_train, y_train)

# Prediction and metrics
y_pred = model.predict(X_test)
r2 = r2_score(y_test, y_pred)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))

# Display model details
print("\nXGBoost Model Feature Importance (approx. impact):")
importance = model.feature_importances_
for feature, imp in zip(X.columns, importance):
    print(f"{feature}: {imp:.4f}") 
print("Intercept: Not applicable (non-linear model)")

# Display performance
print("\nModel Performance:")
print(f"R² Score: {r2:.4f}")
print(f"RMSE (Standardized): {rmse:.4f}")
print(f"RMSE (Original Scale): {rmse:.4f}")  # Assuming no scaling was applied

# Prediction function
def predict_sphericity(ball_size, rpm, time):
    input_data = pd.DataFrame([[ball_size, rpm, time]], columns=['ball_size', 'rpm', 'time'])
    prediction = model.predict(input_data)
    return prediction[0]

# User input
print("\n--- XGBoost Sphericity Prediction ---")
print("Enter the parameter values to predict sphericity:")

try:
    ball_size_input = float(input("Ball Size: "))
    rpm_input = int(input("RPM: "))
    time_input = int(input("Time: "))

    predicted_sphericity = predict_sphericity(ball_size_input, rpm_input, time_input)
    print(f"\nPredicted Sphericity: {predicted_sphericity:.4f}")

except ValueError:
    print("Invalid input. Please enter numeric values.")
